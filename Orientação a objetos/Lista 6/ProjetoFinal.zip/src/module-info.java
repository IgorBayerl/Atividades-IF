module ProjetoFinal {
	requires java.desktop;
}