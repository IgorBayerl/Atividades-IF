package questao5;

public class Imovel {
	private float preco = 50;
	public Imovel(float preco, String endereco) {
		this.preco = preco;
	}
	
	public void setEndereco(String endereco) {
	}
	public float getPreco() {
		return this.preco;
	}
}

